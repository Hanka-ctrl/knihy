﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp11
{
    internal class Regal
    {
        private List<kniha> seznamknih = new List<kniha>();

        public void PridejKnihu(kniha k)
        {
            seznamknih.Add(k);
        }

        public void VratNazev() //varianta 1
        {
            foreach (kniha item in seznamknih)
            {
                Console.WriteLine(item.VratNazev());
            }    
        }

        public string VratNazvy() //varianta 2
        {
            string nazvy = "";
            foreach (kniha item in seznamknih)
            {
                nazvy += item.VratNazev();
            }
            return nazvy;

        }

        public List<kniha> vratSeznam() //varianta 3
        {
            return seznamknih;
        }

    }
}
