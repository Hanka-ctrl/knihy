﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp11
{
    internal class kniha
    {
        public string Nazev { get; private set; }
        private int pocetStran; //nemůžu k tomu přistupovat
        string autor;

        public kniha(string _Nazev)
        {
            Nazev = _Nazev;
        }

        public string VratNazev()
        {
            return Nazev + "@" ; //kdybych si to napsala napřímo, nebude tam tohle
        }

        public string Autor //tady k tomu přistupovat můžu pomocí "fake" autora
        { 
            get { return autor + "xyz"; }  //a můžu si napsat podle sebe něco extra.
            set 
            {
                if (value.Length > 0) //třeba i podmínky
                {
                    autor = value;
                }
            }
        }




    }
}
