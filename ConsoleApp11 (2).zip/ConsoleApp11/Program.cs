﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp11
{
    internal class Program
    {
        static void Main(string[] args)
        {


            kniha k1 = new kniha("Nazev 1");
            kniha k2 = new kniha("Nazev 2");

            Console.WriteLine(k1.Nazev);


            Regal regal = new Regal();

            regal.PridejKnihu(k1);
            regal.PridejKnihu(k2);

            regal.VratNazev();  //varianta 1

            Console.WriteLine(regal.VratNazvy());   //varianta 2 -- nejlepší, tohle pls

            foreach (kniha item in regal.vratSeznam())  //varianta 3
            {
                Console.WriteLine(item.VratNazev());
            }
        }
    }
}
