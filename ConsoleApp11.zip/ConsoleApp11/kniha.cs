﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp11
{
    internal class kniha
    {
        private string Nazev;

        public kniha(string _Nazev)
        {
            Nazev = _Nazev;
        }

        public string VratNazev()
        {
            return Nazev;
        }



    }
}
